﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using SkinnedModelLib;
using BEPUphysics;
using BEPUphysics.Entities;
using BEPUphysics.MathExtensions;
using Microsoft.Xna.Framework.Input;

namespace Animations_and_Particles_Demo
{
    public class AnimatedModelComponent : DrawableGameComponent
    {
        AnimationPlayer animationPlayer;
        Model model;
        Model attachedModel;
        Vector3 localOffset = Vector3.Zero;
        Matrix yawOffset = Matrix.CreateFromYawPitchRoll(MathHelper.Pi, 0, 0);
        Entity physicalData;

        float scale = 10;

        CameraComponent camera;
        public AnimatedModelComponent(MainGame game, Model model, Entity physicalData, Model attachedModel, AnimationPlayer animations)
            : base(game)
        {
            this.model = model;
            this.physicalData = physicalData;
            this.attachedModel = attachedModel;
            this.animationPlayer = animations;

            camera = game.Services.GetService(typeof(CameraComponent)) as CameraComponent;

            animationPlayer.StartClip(animationPlayer.skinningDataValue.AnimationClips.Keys.First(), MixType.None);
        }

        Dictionary<Type, ParticleEmitter> emitters = new Dictionary<Type, ParticleEmitter>();
        public void AddEmitter(Type particleType, float particlesPerSecond, int maxOffset, Vector3 offsetFromCenter, int attachIndex)
        {
            if (!emitters.ContainsKey(particleType))
            {
                emitters.Add(particleType, new ParticleEmitter((Game.Services.GetService(typeof(ParticleManager)) as ParticleManager).GetSystem(particleType),
                    particlesPerSecond, physicalData.Position, maxOffset, offsetFromCenter, attachIndex));
            }
        }

        protected Vector3 vLightDirection = new Vector3(-1.0f, -.5f, 1.0f);
        Matrix rot = Matrix.Identity;
        public override void Update(GameTime gameTime)
        {
            //need to do this conversion from BEPU's Matrix3x3 to XNA's Matrix object
            Matrix3X3 bepurot = physicalData.OrientationMatrix;
            rot = new Matrix(bepurot.M11, bepurot.M12, bepurot.M13, 0, bepurot.M21, bepurot.M22, bepurot.M23, 0, bepurot.M31, bepurot.M32, bepurot.M33, 0, 0, 0, 0, 1);
            rot *= yawOffset;

            Matrix conglomeration = Matrix.CreateScale(new Vector3(scale));
            conglomeration *= Matrix.CreateTranslation(localOffset);
            conglomeration *= rot;
            conglomeration *= Matrix.CreateTranslation(physicalData.Position);

            animationPlayer.Update(gameTime.ElapsedGameTime, true, conglomeration);


            List<Type> toRemove = new List<Type>();
            foreach (KeyValuePair<Type, ParticleEmitter> k in emitters)
            {
                if (k.Value.BoneIndex < 0)
                {
                    k.Value.Update(gameTime, physicalData.Position, rot);
                }
                else
                {
                    Vector3 bonePos = animationPlayer.GetWorldTransforms()[k.Value.BoneIndex].Translation;
                    k.Value.Update(gameTime, bonePos, rot);
                }
            }
        }

        public override void Draw(GameTime gameTime)
        {
            Matrix[] bones = animationPlayer.GetSkinTransforms();

            Matrix view = camera.View;
            Matrix projection = camera.Projection;


            //drawing main mesh
            foreach (ModelMesh mesh in model.Meshes)
            {
                
                foreach (CustomSkinnedEffect effect in mesh.Effects)
                {
                    effect.SetBoneTransforms(bones);
                    effect.View = view;
                    effect.Projection = projection;
                }
                /*
                foreach (SkinnedEffect effect in mesh.Effects)
                {
                    effect.EnableDefaultLighting();
                    effect.SetBoneTransforms(bones);
                    effect.View = view;
                    effect.Projection = projection;
                }*/
                mesh.Draw();
            }


            if (attachedModel != null)
            {
                //drawing attached model
                Matrix[] worldbones = animationPlayer.GetWorldTransforms();
                Matrix[] transforms;
                transforms = new Matrix[attachedModel.Bones.Count];
                attachedModel.CopyAbsoluteBoneTransformsTo(transforms);
                foreach (ModelMesh mesh in attachedModel.Meshes)
                {
                    foreach (BasicEffect effect in mesh.Effects)
                    {
                        effect.World = Matrix.CreateFromYawPitchRoll(0, 0, 0)
                            * transforms[mesh.ParentBone.Index]
                            * worldbones[model.Bones["Hand_R"].Index - 2];

                        effect.View = view;
                        effect.Projection = projection;
                    }
                    mesh.Draw();
                }
            }
        }
    }
}
