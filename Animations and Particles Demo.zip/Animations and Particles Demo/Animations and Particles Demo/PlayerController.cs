﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;
using BEPUphysics;
using BEPUphysics.Entities;
using BEPUphysics.MathExtensions;
using BEPUphysics.BroadPhaseEntries;
using BEPUphysics.CollisionRuleManagement;
using BEPUphysics.ResourceManagement;
using BEPUphysics.Entities.Prefabs;
using BEPUphysics.Collidables;
using SkinnedModelLib;

namespace Animations_and_Particles_Demo
{
    public class PlayerController : GameComponent
    {
        Space physics;
        CameraComponent camera;
        Entity physicalData;

        AnimationPlayer animations;

        public PlayerController(Game game, Entity physicalData, AnimationPlayer animations)
            : base(game)
        {

            this.physicalData = physicalData;
            this.animations = animations;
            physics = Game.Services.GetService(typeof(Space)) as Space;
            camera = Game.Services.GetService(typeof(CameraComponent)) as CameraComponent;

            PlayAnimation("idle", MixType.None);
        }

        string currentAniName = "";
        private void PlayAnimation(string animationName, MixType t)
        {
            animations.StartClip(animationName, t);
            currentAniName = animationName;

            //description of mixtype parameter:
            /*
                enum MixType
                {
                    None,
                    MixOnce,//plays the specified animation once and mixes back into the one that was already playing (good for a hit animation, where the enemy plays the animation of it getting hit and mixes back into what it was already doing)
                    MixInto,//mixes from the animation already playing into the new one (good for transitioning between states, like idle to walking or attacking to idle)
                    PauseAtEnd,//pauses the animation at the end (I used this for syncing animations being played by different models; also good for making sure an animation doesn't loop back to the beginning if you only want it to play once)
                }
             */
        }

        MouseState curMouse = Mouse.GetState();
        MouseState prevMouse = Mouse.GetState();
        public override void Update(GameTime gameTime)
        {
            curMouse = Mouse.GetState();
            prevMouse = Mouse.GetState();


            //move if pressing down left button
            if (curMouse.LeftButton == ButtonState.Pressed)
            {
                Vector3 mouseHoveredLocation = Vector3.Zero;

                //creating ray from mouse location
                Vector3 castOrigin = Game.GraphicsDevice.Viewport.Unproject(new Vector3(curMouse.X, curMouse.Y, 0), camera.Projection, camera.View, Matrix.Identity);
                Vector3 castdir = Game.GraphicsDevice.Viewport.Unproject(new Vector3(curMouse.X, curMouse.Y, 1), camera.Projection, camera.View, Matrix.Identity) - castOrigin;
                castdir.Normalize();
                Ray r = new Ray(castOrigin, castdir);

                //check where on the zero plane the ray hits, to guide the character by the mouse
                float? distance;
                Plane p = new Plane(Vector3.Up, 0);
                r.Intersects(ref p, out distance);
                if (distance.HasValue)
                {
                    mouseHoveredLocation = r.Position + r.Direction * distance.Value;
                }

                Vector3 move = mouseHoveredLocation - physicalData.Position;


                //move character
                Vector3 moveVec = move * 120;
                moveVec.Y = 0;

                physicalData.LinearVelocity = moveVec;

                //orientation
                float yaw = (float)Math.Atan(move.X / move.Z);
                if (move.Z < 0 && move.X >= 0
                    || move.Z < 0 && move.X < 0)
                {
                    yaw += MathHelper.Pi;
                }
                yaw += MathHelper.Pi;
                physicalData.Orientation = Quaternion.CreateFromYawPitchRoll(yaw, 0, 0);


                //just started running
                if (currentAniName != "walk")
                {
                    PlayAnimation("walk", MixType.None);
                }
            }
            else
            {
                //stop character if no input
                physicalData.LinearVelocity = Vector3.Zero;
                if (currentAniName != "idle")
                {
                    PlayAnimation("idle", MixType.None);
                }
            }

            prevMouse = curMouse;
        }



        protected float GetGraphicsYaw(Vector3 move)
        {
            Vector3 lmove = new Vector3();
            lmove.X = move.X;
            lmove.Y = move.Y;
            lmove.Z = move.Z;
            if (lmove.Z == 0)
            {
                lmove.Z = .00000001f;
            }
            else
            {
                lmove.Normalize();
            }
            float yaw = (float)Math.Atan(lmove.X / lmove.Z);
            if (lmove.Z < 0 && lmove.X >= 0
                || lmove.Z < 0 && lmove.X < 0)
            {
                yaw += MathHelper.Pi;
            }
            yaw += MathHelper.Pi;
            return yaw;
        }
        protected float GetPhysicsYaw(Vector3 move)
        {
            float retYaw = -GetGraphicsYaw(move) - MathHelper.PiOver2;
            while (retYaw > MathHelper.TwoPi)
            {
                retYaw -= MathHelper.TwoPi;
            }
            while (retYaw < 0)
            {
                retYaw += MathHelper.TwoPi;
            }

            return retYaw;
        }

    }
}
