using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using BEPUphysics;
using BEPUphysics.Collidables;
using BEPUphysics.Entities;
using BEPUphysics.Entities.Prefabs;
using BEPUphysics.CollisionRuleManagement;
using BEPUphysicsDrawer;
using BEPUphysicsDrawer.Lines;

using SkinnedModelLib;

namespace Animations_and_Particles_Demo
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class MainGame : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        BoundingBoxDrawer modelDrawer;
        CameraComponent camera;
        Space physics;

        ParticleManager particleManager;
        BasicEffect effectModelDrawer;
        Effect skinningEffect;

        public MainGame()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";


            physics = new Space();

            if (Environment.ProcessorCount > 1)
            {
                for (int i = 0; i < 10 * Environment.ProcessorCount; ++i)
                {
                    physics.ThreadManager.AddThread();
                }
            }
            physics.ForceUpdater.Gravity = new Vector3(0, -1600, 0);
            Services.AddService(typeof(Space), physics);


        }

        protected override void Initialize()
        {

            bool fullscreen = false;

            if (fullscreen)
            {
                graphics.PreferredBackBufferWidth = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width;
                graphics.PreferredBackBufferHeight = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height;
                graphics.IsFullScreen = true;
                graphics.ApplyChanges();
            }
            else
            {
                graphics.PreferredBackBufferWidth = 800;
                graphics.PreferredBackBufferHeight = 600;
                graphics.IsFullScreen = false;
                graphics.ApplyChanges();
            }

            camera = new CameraComponent(this);
            Components.Add(camera);
            Services.AddService(typeof(CameraComponent), camera);

            particleManager = new ParticleManager(this);
            Components.Add(particleManager);
            Services.AddService(typeof(ParticleManager), particleManager);

            //debug drawing
            modelDrawer = new BoundingBoxDrawer(this);



            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            effectModelDrawer = new BasicEffect(GraphicsDevice);

            skinningEffect = Content.Load<Effect>("CustomSkinnedEffect");

            InitializePlayer();

            base.LoadContent();
        }

        public void InitializePlayer()
        {
            //make the player's physics
            Entity playerBox = new Box(Vector3.Zero, 10, 10, 10, 10);
            //tell the camera to follow it
            camera.FollowEntity(playerBox);

            //load models
            Model playerModel = GetAnimatedModel("idle");
            Model attachedModel = Content.Load<Model>("sword01");
            //get animation data from the model (the content processor added it to the model's Tag field)
            AnimationPlayer animations = new AnimationPlayer(playerModel.Tag as SkinningData);

            AnimatedModelComponent playerGraphics = new AnimatedModelComponent(this, playerModel, playerBox, attachedModel, animations);
            //AnimatedModelComponent playerGraphics = new AnimatedModelComponent(this, playerModel, playerBox, null, animations);
            //playerGraphics.AddEmitter(typeof(WeaponSparksSystem), 50, 0, Vector3.Zero, 5);

            PlayerController playerController = new PlayerController(this, playerBox, animations);

            Components.Add(playerGraphics);
            Components.Add(playerController);
        }


        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Space))
            {
                ParticleSystem explosionSystem = particleManager.GetSystem(typeof(WeaponSparksSystem));
                for (int i = 0; i < 30; ++i)
                {
                   // explosionSystem.AddParticle(Vector3.Zero, Vector3.Zero);
                }
            }


            base.Update(gameTime);
        }


        protected override void Draw(GameTime gameTime)
        {

            //draw depth render target
            GraphicsDevice.Clear(Color.Black);
            GraphicsDevice.BlendState = BlendState.NonPremultiplied;
            GraphicsDevice.DepthStencilState = DepthStencilState.Default;
            GraphicsDevice.SamplerStates[0] = SamplerState.LinearWrap;

            base.Draw(gameTime);

            //draw particles
            particleManager.Draw(gameTime);




            //physics debugging
            /*
            effectModelDrawer.LightingEnabled = false;
            effectModelDrawer.VertexColorEnabled = true;
            effectModelDrawer.World = Matrix.Identity;
            effectModelDrawer.View = camera.View;
            effectModelDrawer.Projection = camera.Projection;
            modelDrawer.Draw(effectModelDrawer, physics);
            */

        }


        Dictionary<string, Model> animatedModels = new Dictionary<string, Model>();

        public Model GetAnimatedModel(string filePath)
        {
            Model m;
            if (animatedModels.TryGetValue(filePath, out m))
            {
                return m;
            }
            else
            {
                LoadAnimatedModel(out m, filePath);
                animatedModels.Add(filePath, m);
                return m;
            }
        }

        public void LoadAnimatedModel(out Model model, string filePath)
        {
            model = Content.Load<Model>(filePath);
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (ModelMeshPart part in mesh.MeshParts)
                {
                    SkinnedEffect skinnedEffect = part.Effect as SkinnedEffect;
                    if (skinnedEffect != null)
                    {
                        CustomSkinnedEffect newEffect = new CustomSkinnedEffect(skinningEffect);
                        newEffect.CopyFromSkinnedEffect(skinnedEffect);
                        part.Effect = newEffect;
                    }
                }
            }
        }
    }
}
